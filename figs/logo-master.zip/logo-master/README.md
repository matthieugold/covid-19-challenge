
### Different versions of the logo are available

#### Basic
<img src="png/logo-w600px.png" width="500px" alt="basic logo">

#### Square
<img src="png/logo-square-w600px.png" width="500px" alt="square logo">

#### Sticker
<img src="png/logo-sticker.png" width="500px" alt="sticker logo">





#### Source & redistribution
The RECON logo is distributed under [CC-BY-SA](https://creativecommons.org/licenses/by-sa/4.0/) 4.0. 

Copyright: Thibaut Jombart (thibautjombart@gmail.com), 2016.
